<?php 


function sudah_login(){
	$ci =& get_instance();
	$sesi_user = $ci->session->userdata('ud');
	if ($sesi_user) {
		redirect('admin');
	}
}

function belum_login(){
	$ci =& get_instance();
	$sesi_user = $ci->session->userdata('ud');
	if (!$sesi_user) {
		redirect('login');
	}
}

function rupiah($v)
{
	return "Rp. ".number_format($v, 0, ",", ".");
}

if (!function_exists('format_indo')) {
  function format_indo($date){
    $date = date("Y-m-d", strtotime($date));
    date_default_timezone_set('Asia/Jakarta');
    // array hari dan bulan
    $Hari = array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");
    $Bulan = array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
    
    // pemisahan tahun, bulan, hari, dan waktu
    $tahun = date("Y", strtotime($date));
    $bulan = date("m", strtotime($date));
    $tgl = date("d", strtotime($date));
    // $waktu = date("H:i:s", strtotime($date));
    $hari = date("w",strtotime($date));
    $result = $Hari[$hari].", ".$tgl." ".$Bulan[(int)$bulan-1]." ".$tahun;

    return $result;
  }
}

function denda($d)
{
    $tggl1 = date('d-m-Y');
    $tggl2 = date('d', strtotime($d));
    $bln1 = date('m');
    $bln2 = date('m', strtotime($d));

    if ($bln1 == $bln2) {
        if ($tggl1 >= $tggl2) {
            $tgl1 = new DateTime($d);
            $tgl2 = new DateTime();
            $d = $tgl2->diff($tgl1)->days;
            $hasil = $d*500;
            if ($d == null ) {
                return 0;
            }else{
                return $hasil;
            }
        }
    }elseif ($bln1 > $bln2) {
        $tgl1 = new DateTime($d);
        $tgl2 = new DateTime();
        $d = $tgl2->diff($tgl1)->days;
        $hasil = $d*500;
        if ($d == null ) {
            return 0;
        }else{
            return $hasil;
        }
    }
}


function denda2($d,$l)
{
    $tggl1 = date('d', strtotime($l));
    $tggl2 = date('d', strtotime($d));
    $bln1 = date('m', strtotime($l));
    $bln2 = date('m', strtotime($d));


    if ($bln1 == $bln2) {
        if ($tggl1 <= $tggl2) {
            $tgl1 = new DateTime($d);
            $tgl2 = new DateTime($l);
            $d = $tgl2->diff($tgl1)->days;
            $hasil = $d*500;
            if ($d == null ) {
                return 0;
            }else{
                return $hasil;
            }
        }
    }elseif ($bln1 < $bln2) {
        $tgl1 = new DateTime($d);
        $tgl2 = new DateTime($l);
        $d = $tgl2->diff($tgl1)->days;
        $hasil = $d*500;
        if ($d == null ) {
            return 0;
        }else{
            return $hasil;
        }
    }
}