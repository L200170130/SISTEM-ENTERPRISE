<?php
class M_human extends CI_Model{

	function get_all_human(){
		$hsl=$this->db->query("SELECT * FROM human");
		return $hsl;
	}

	function simpan_human($nama,$devisi,$jabatan){
	 	/*$author=$this->session->userdata('nama');*/
	 	$hsl=$this->db->query("INSERT INTO human(`idkaryawan`, `nama`, `devisi`, `jabatan`) VALUES (null,'$nama','$devisi','$jabatan')");
	 	return $hsl;
	}

	function update_human($idkaryawan,$nama,$devisi,$jabatan){
	 	$hsl=$this->db->query("UPDATE human SET idkaryawan='$idkaryawan',nama='$nama',devisi='$devisi',jabatan='$jabatan' where idkaryawan='$idkaryawan'");
	 	return $hsl;
	}

	function hapus_human($idkaryawan){
	 	$hsl=$this->db->query("DELETE FROM human WHERE idkaryawan='$idkaryawan'");
	 	return $hsl;
	}
 
	// //Front-end
	// function get_pengumuman_home(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit 3");
	// 	return $hsl;
	// }

	// function pengumuman(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC");
	// 	return $hsl;
	// }
	// function pengumuman_perpage($offset,$limit){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit $offset,$limit");
	// 	return $hsl;
	// }


} 