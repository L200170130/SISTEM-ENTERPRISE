<?php
class M_Integrasi extends CI_Model{

	function get_all_integrasi(){
		$hsl=$this->db->query("SELECT * FROM sistemintegrasi");
		return $hsl;
	}
 	
	function simpan_integrasi($nama,$tanggal,$biaya){
	 	$hsl=$this->db->query("INSERT INTO sistemintegrasi(idsistem,nama,tanggal,biaya) VALUES (null,'$nama','$tanggal','$biaya')");
	 	return $hsl;
	}

	function simpan_akuntansi($nama,$tanggal,$biaya){
	 	$hsl=$this->db->query("INSERT INTO accounting(idakuntan,jenisakuntansi,namaakuntansi,tanggal,Jumlah) VALUES (null,'Pengeluaran','$nama','$tanggal','$biaya')");
	 	return $hsl;
	}

	function update_integrasi($idintegrasi,$nama,$tanggal,$biaya){
	 	$author=$this->session->userdata('nama');
	 	$hsl=$this->db->query("UPDATE sistemintegrasi SET idsistem='$idintegrasi',nama='$nama',tanggal='$tanggal',biaya='$biaya' where idsistem='$idintegrasi'");
	 	return $hsl;
	}

	function hapus_integrasi($idintegrasi){
	 	$hsl=$this->db->query("DELETE FROM sistemintegrasi WHERE idsistem='$idintegrasi'");
	 	return $hsl;
	}

	// //front-end
	// function get_agenda_home(){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC limit 3");
	// 	return $hsl;
	// }
	// function agenda(){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC");
	// 	return $hsl;
	// }
	// function agenda_perpage($offset,$limit){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC limit $offset,$limit");
	// 	return $hsl;
	// }


} 