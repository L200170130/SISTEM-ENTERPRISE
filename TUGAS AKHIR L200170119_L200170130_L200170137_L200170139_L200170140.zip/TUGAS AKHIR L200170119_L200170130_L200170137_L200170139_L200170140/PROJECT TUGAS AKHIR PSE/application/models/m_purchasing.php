<?php 
class M_purchasing extends CI_Model{

	function get_all_purchasing(){
		$hsl=$this->db->query("SELECT * FROM pembelian");
		return $hsl;
	}

	function simpan_purchasing($nama,$tanggal,$biaya){
	 	$hsl=$this->db->query("INSERT INTO pembelian (idpembelian,namapembelian,tanggal,biaya) VALUES (null,'$nama','$tanggal','$biaya')");
		return $hsl;
	}

	function simpan_akuntansi($nama,$tanggal,$biaya){
	 	$hsl=$this->db->query("INSERT INTO accounting(idakuntan,jenisakuntansi,namaakuntansi,tanggal,Jumlah) VALUES (null,'Pengeluaran','$nama','$tanggal','$biaya')");
	 	return $hsl;
	}
 

	function update_purchasing($idpembelian,$nama,$tanggal,$biaya){
	 	$hsl=$this->db->query("UPDATE pembelian SET idpembelian='$idpembelian',namapembelian='$nama',tanggal='$tanggal',biaya='$biaya' WHERE idpembelian='$idpembelian'");
	 	return $hsl;
	}
	
    function hapus_purchasing($idpembelian){
	 	$hsl=$this->db->query("DELETE FROM pembelian WHERE idpembelian='$idpembelian'");
	 	return $hsl;
	}

}