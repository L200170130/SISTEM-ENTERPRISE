<?php
class M_payroll extends CI_Model{

	function get_all_payroll(){
		$hsl=$this->db->query("SELECT * FROM payroll JOIN human ON payroll.idkaryawan = human.idkaryawan");
		return $hsl;
	}
		function get_all_humandata(){
		$hsl1=$this->db->query("SELECT * FROM human");
		return $hsl1;
	}

	function simpan_payroll($tanggal,$idkaryawan,$biaya){
	 	/*$author=$this->session->userdata('nama');*/
	 	$hsl=$this->db->query("INSERT INTO payroll(idpayroll, tanggalgaji, gaji, idkaryawan) VALUES (null,'$tanggal','$biaya','$idkaryawan')");
	 	return $hsl;
	}
 
	function simpan_akuntansi($tanggal,$idkaryawan,$biaya){
		$oke=$this->db->query("SELECT * FROM human where idkaryawan='$idkaryawan'");
		foreach ($oke->result_array() as $i) :
                       $nama=$i['nama'];
        endforeach;
	 	$hsl=$this->db->query("INSERT INTO accounting(idakuntan,jenisakuntansi,namaakuntansi,tanggal,Jumlah) VALUES (null,'Pengeluaran','Gj.Pg $nama','$tanggal','$biaya')");
	 	return $hsl;
	}

	function update_payroll($idpayroll,$tanggal,$idkaryawan,$biaya){
	 	$hsl=$this->db->query("UPDATE payroll SET tanggalgaji='$tanggal',gaji='$biaya',idkaryawan='$idkaryawan' where idpayroll='$idpayroll'");
	 	return $hsl;
	}

	function hapus_payroll($idpayroll){
	 	$hsl=$this->db->query("DELETE FROM payroll WHERE idpayroll='$idpayroll'");
	 	return $hsl;
	}

	// //Front-end
	// function get_pengumuman_home(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit 3");
	// 	return $hsl;
	// }

	// function pengumuman(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC");
	// 	return $hsl;
	// }
	// function pengumuman_perpage($offset,$limit){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit $offset,$limit");
	// 	return $hsl;
	// }


} 