<?php
class M_sistem extends CI_Model{

	public function tampil_data_barang($id = null)
    {
    	if ($id != null) {
    		$this->db->where('idbarang', $id);
    	}
    	
        return $this->db->get('inventory');
    }


    public function tambah()
    {
		$data = $this->input->post(null, true);
		$harga = $this->tampil_data_barang($data['sepatu'])->result();
		$params = [
			'barangid' => $data['sepatu'],
			'harga' => $harga[0]->hargabarang,
			'qty' => $data['qty'],
			'total' => $harga[0]->hargabarang*$data['qty'],
			'tanggal' => date('Y-m-d'),
			'user_id' => $this->session->userdata('idadmin'),
			'bayar' => '0'
		];
		$this->db->insert('orders', $params);
    }

    public function edit()
    {
		$data = $this->input->post(null, true);
		$harga = $this->tampil_data_barang($data['sepatu'])->result();
		$params = [
			'barangid' => $data['sepatu'],
			'harga' => $harga[0]->hargabarang,
			'qty' => $data['qty'],
			'total' => $harga[0]->hargabarang*$data['qty'],
			'tanggal' => date('Y-m-d'),
			'user_id' => $this->session->userdata('idadmin'),
			'bayar' => '0',
		];
		$this->db->where('idorder', $data['gid1']);
		$this->db->update('orders', $params);
    }

    public function bayar()
    {
		$data = $this->input->post(null, true);
		$code = $this->buatcode();
		$params = [
			'code' => $code,
			'user_id' => $this->session->userdata('idadmin'),
			'total_bayar' => $data['Total'],
			'uang' => $data['nominal'],
			'kembalian' => $data['kembalian'],
			'tanggal' => date('Y-m-d')
		];
		$this->db->insert('transaksi', $params);
		$params2 = [
			'code' => $code,
			'bayar' => '1'
		];
		$this->db->where('code', null);
		$this->db->update('orders', $params2);

    }


    public function datapesanan($id=null)
    {
    	if ($id != null) {
    		$this->db->where('idorder', $id);
    	}
        $this->db->select('inventory.*, orders.*');
    	$this->db->where('bayar', '0');
		$this->db->from('orders');
		$this->db->join('inventory', 'inventory.idbarang = orders.barangid');

		
		$query = $this->db->get();
		return $query->result_array();
    }

	function get_data_barang_bykode($id){
		$hsl=$this->db->query("SELECT * FROM inventory WHERE idbarang='$id'");
		if($hsl->num_rows()>0){
			foreach ($hsl->result() as $data) {
				$hasil=array(
					'idbarang' => $data->idbarang,
					'namabarang' => $data->namabarang,
					'hargabarang' => $data->hargabarang,
					);
			}
		}
		return $hasil;
    }

    public function ambilcode()
	{
		$this->db->select('code');
		$this->db->from('orders');
		$query = $this->db->get();
		return $query->result_array();

	}

    public function buatcode()
	{
		$code = $this->ambilcode();
		$permitted_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$data = substr(str_shuffle($permitted_chars), 0, 9);
		foreach ($code as $cek_code) {
			if ($cek_code == $data) {
				buatcode();
			}
		}
		return $data;
	}

	public function hapus($id='')
	{
		$this->db->where('idorder', $id);
		$this->db->delete('orders');
	}

} 