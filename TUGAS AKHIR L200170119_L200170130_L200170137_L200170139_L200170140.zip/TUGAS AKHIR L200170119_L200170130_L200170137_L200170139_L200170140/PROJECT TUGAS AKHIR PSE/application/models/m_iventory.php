<?php 
class M_iventory extends CI_Model{

	function get_all_iventory(){
		$hsl=$this->db->query("SELECT * FROM inventory");
		return $hsl->result_array();
	}

	function simpan_iventory($namabarang,$hargabarang,$stokbarang){
	 	$hsl=$this->db->query("INSERT INTO inventory (idbarang,hargabarang,stokbarang,namabarang) VALUES (null,'$hargabarang','$stokbarang','$namabarang')");
		return $hsl;
	}

	function update_iventory($idbarang,$namabarang,$hargabarang,$stokbarang){
	 	$hsl=$this->db->query("UPDATE inventory SET idbarang='$idbarang',hargabarang='$hargabarang',stokbarang='$stokbarang',namabarang='$namabarang' WHERE idbarang='$idbarang'");
	 	return $hsl;
	}
	
    function hapus_iventory($idbarang){
	 	$hsl=$this->db->query("DELETE FROM inventory WHERE idbarang='$idbarang'");
	 	return $hsl;
	}

}