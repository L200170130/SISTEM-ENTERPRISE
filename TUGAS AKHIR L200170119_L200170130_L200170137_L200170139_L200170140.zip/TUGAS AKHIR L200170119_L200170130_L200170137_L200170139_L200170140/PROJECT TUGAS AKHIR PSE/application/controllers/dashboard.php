<?php
class Dashboard extends CI_Controller{
	function __construct(){
		parent::__construct();
	}
	function index(){
		$data = [
			'base' => 'admin/v_dashboard'
		];
		$this->load->view('base/base', $data);
	}
	
}