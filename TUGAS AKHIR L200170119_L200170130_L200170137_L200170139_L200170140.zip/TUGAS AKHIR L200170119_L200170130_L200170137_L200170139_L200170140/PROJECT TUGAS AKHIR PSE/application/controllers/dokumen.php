<?php
class dokumen extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_dokumen');
	}


	function index(){
		$x['data']=$this->m_dokumen->get_all_dokumen();
		$x['base']='admin/v_dokumen';
		$this->load->view('base/base',$x);
	}
	
	// perintah php untuk akses ke database

	function simpan_dokumen(){
		$jenis=strip_tags($this->input->post('xjenis'));
		$nama=strip_tags($this->input->post('xnama'));
		$link=strip_tags($this->input->post('xlink'));
		$this->m_dokumen->simpan_dokumen($jenis,$nama,$link);
		redirect('dokumen');
	}
	
 	function update_dokumen(){
		$id=strip_tags($this->input->post('xid'));
		$jenis=strip_tags($this->input->post('xjenis'));
		$nama=strip_tags($this->input->post('xnama'));
		$link=strip_tags($this->input->post('xlink'));
		$this->m_dokumen->update_dokumen($id,$jenis,$nama,$link);
		redirect('dokumen');
	}

	function hapus_dokumen(){
		$id=strip_tags($this->input->post('xid'));
		$this->m_dokumen->hapus_dokumen($id);
		redirect('dokumen');
	}

}