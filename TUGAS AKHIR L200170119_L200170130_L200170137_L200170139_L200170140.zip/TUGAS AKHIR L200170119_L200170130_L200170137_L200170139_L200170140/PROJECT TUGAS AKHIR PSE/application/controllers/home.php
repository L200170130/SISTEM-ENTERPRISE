<?php
class Home extends CI_Controller{
    function __construct(){
        parent:: __construct();
    }
    function index(){
        if ($this->session->userdata('masuk') == true) {
            redirect('dashboard');
        }else{
            $this->load->view('admin/v_login');
        }
    }
    function logout(){
        $this->session->sess_destroy();
        redirect(base_url('administrator'));
    }
}