<?php
class Produksi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_produksi');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_produksi->get_all_produksi();
		$x['data1']=$this->m_produksi->get_all_barangproduksi();
		$x['base'] = 'admin/v_produksi';
		$this->load->view('base/base',$x);
	}

 
	function simpan_produksi(){
		$tanggal=$this->input->post('xtanggal');
		$totalproduksi=$this->input->post('xtotalproduksi');		
		$biayaproduksi=$this->input->post('xbiayaproduksi');
		$idbarang=$this->input->post('xidbarang');
		$this->m_produksi->simpan_produksi($tanggal,$totalproduksi,$biayaproduksi,$idbarang);
		$this->m_produksi->simpan_akuntansi($tanggal,$biayaproduksi,$idbarang);
		$this->m_produksi->simpan_stok($totalproduksi,$idbarang);
		echo $this->session->set_flashdata('msg','success');
		redirect('produksi');
	}

	function update_produksi(){
		$idproduksi=strip_tags($this->input->post('xidproduksi'));
		$tanggal=$this->input->post('xtanggal');
		$totalproduksi=$this->input->post('xtotalproduksi');
		$biayaproduksi=$this->input->post('xbiayaproduksi');
		$idbarang=$this->input->post('xidbarang');
		$this->m_produksi->update_produksi($idproduksi,$tanggal,$totalproduksi,$biayaproduksi,$idbarang);
		echo $this->session->set_flashdata('msg','info');
		redirect('produksi');
	}
	function hapus_produksi($id=''){
		$this->m_produksi->hapus_produksi($id);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('produksi');
	}

}