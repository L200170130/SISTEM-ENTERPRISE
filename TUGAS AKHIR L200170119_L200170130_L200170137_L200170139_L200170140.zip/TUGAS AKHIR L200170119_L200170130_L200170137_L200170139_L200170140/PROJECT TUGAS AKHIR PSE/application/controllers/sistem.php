<?php
class Sistem extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_sistem');
	}

	function index(){
		$data = [
			'databarang' => $this->m_sistem->tampil_data_barang()->result_array(),
			'datapesanan' => $this->m_sistem->datapesanan(),
			'base' => 'admin/sistem'
		];
		$masuk = $this->input->post(null, true);
		if (isset($masuk['tambah'])) {
			$order = $this->m_sistem->tambah();
			if ($order ==  true) {	
				redirect('sistem');
			}else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Mohon masukkan data yang sesuai</div>');
				redirect('sistem');
			}
		}elseif (isset($masuk['edit'])) {
			$order = $this->m_sistem->edit();
			if ($order ==  true) {	
				redirect('sistem');
			}else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Mohon masukkan data yang sesuai</div>');
				redirect('sistem');
			}
		}elseif (isset($masuk['bayar'])) {
			$order = $this->m_sistem->bayar();
			if ($order ==  true) {	
				redirect('sistem');
			}else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Mohon masukkan data yang sesuai</div>');
				redirect('sistem');
			}
		}else{
			$this->load->view('base/base', $data);
		}
	}

	public function hapus($id='')
	{
		$hapus = $this->m_sistem->hapus($id);
		if (isset($hapus)) {
			redirect('sistem');
		}else{
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Data gagal dihapus</div>');
			redirect('sistem');
		}
	}



}