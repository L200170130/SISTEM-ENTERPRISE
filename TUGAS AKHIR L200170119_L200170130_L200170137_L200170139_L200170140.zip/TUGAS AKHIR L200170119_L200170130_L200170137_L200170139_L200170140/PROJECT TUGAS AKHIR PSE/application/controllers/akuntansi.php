<?php
class Akuntansi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_akuntansi');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_akuntansi->get_all_akuntansi();
		$x['base']= 'admin/v_akuntansi';
		$this->load->view('base/base',$x);
	}


	function simpan_akuntansi(){
		$jenis=$this->input->post('xjenis');
		$nama=$this->input->post('xnama');		
		$tanggal=$this->input->post('xtanggal');
		$jumlah=$this->input->post('xjumlah');		
		$this->m_akuntansi->simpan_akuntansi($jenis,$nama,$tanggal,$jumlah);
		echo $this->session->set_flashdata('msg','success');
		redirect('akuntansi');
	}

	function update_akuntansi(){
		$idakuntansi=strip_tags($this->input->post('xidakuntansi'));
		$jenis=$this->input->post('xjenis');
		$nama=$this->input->post('xnama');		
		$tanggal=$this->input->post('xtanggal');
		$jumlah=$this->input->post('xjumlah');	
		$this->m_akuntansi->update_akuntansi($idakuntansi,$jenis,$nama,$tanggal,$jumlah);
		echo $this->session->set_flashdata('msg','info');
		redirect('akuntansi');
	}
	function hapus_akuntansi($id=''){
		
		$this->m_akuntansi->hapus_akuntansi($id);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('akuntansi');
	}

}