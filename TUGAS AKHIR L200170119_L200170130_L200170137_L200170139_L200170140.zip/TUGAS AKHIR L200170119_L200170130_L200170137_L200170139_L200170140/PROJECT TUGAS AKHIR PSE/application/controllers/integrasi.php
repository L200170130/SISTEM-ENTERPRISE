<?php
class Integrasi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_integrasi');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_integrasi->get_all_integrasi();
		$x['base']='admin/v_integrasi';
		$this->load->view('base/base',$x);
	}

	function simpan_integrasi(){
	 	$nama=$this->input->post('xnama');
	 	$tanggal=$this->input->post('xtanggal');
	 	$biaya=$this->input->post('xbiaya');
	 	$this->m_integrasi->simpan_integrasi($nama,$tanggal,$biaya);
		$this->m_integrasi->simpan_akuntansi($nama,$tanggal,$biaya);
	 	echo $this->session->set_flashdata('msg','success');
	 	redirect('integrasi');
	}

	function update_integrasi(){
		$idintegrasi=strip_tags($this->input->post('xid'));
	 	$nama=$this->input->post('xnama');
	 	$tanggal=$this->input->post('xtanggal');
	 	$biaya=$this->input->post('xbiaya');
	 	$this->m_integrasi->update_integrasi($idintegrasi,$nama,$tanggal,$biaya);
	 	echo $this->session->set_flashdata('msg','info');
	 	redirect('integrasi');
	}

	function hapus_integrasi(){
		$idintegrasi=strip_tags($this->input->post('xid'));
	 	$this->m_integrasi->hapus_integrasi($idintegrasi);
	 	echo $this->session->set_flashdata('msg','success-hapus');
	 	redirect('integrasi');
	}

}