<?php
class Marketing extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_marketing');
		$this->load->library('upload');
	}
 

	function index(){
		$x = [
			'data'=> $this->m_marketing->get_all_marketing(),
			'base' => 'admin/v_marketing'
		];

		$input = $this->input->post(null, true);
		if (isset($input['tambah'])) {

			$this->m_marketing->simpan_marketing();
			$this->m_marketing->simpan_akuntansi();
		 	redirect('marketing');
		}elseif (isset($input['edit'])) {
		 	$this->m_marketing->update_marketing();
		 	redirect('marketing');
		}

		$this->load->view('base/base',$x);
	}

	
	function hapus($id=''){
	 	$this->m_marketing->hapus($id);
	 	redirect('marketing');
	}

}