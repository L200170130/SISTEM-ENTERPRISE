
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add</button>




        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Kegiatan</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal</th>
                    <th><i class=" fa fa-edit"></i> Biaya</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['nama'] ?></td>
                    <td><?= $datas['tanggal'] ?></td>
                    <td><?= $datas['biaya'] ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idsistem'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                     <div class="modal fade" id="ganti<?= $datas['idsistem'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                  <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                                      <h4 class="modal-title" id="myModalLabel">Edit</h4>
                                  </div>
                                  <form class="form-horizontal" action="<?php echo base_url().'integrasi/update_integrasi'?>" method="post" enctype="multipart/form-data">
                                  <div class="modal-body">
                                              
                                          <div class="form-group">
                                              <div class="col-sm-7">
                                                <input type="hidden" name="xid" value="<?= $datas['idsistem'] ?>">
                                              </div>
                                          </div>

                                          <div class="form-group">
                                              <label for="inputUserName" class="col-sm-4 control-label">Nama Kegiatan</label>
                                              <div class="col-sm-7">
                                                <input type="text" name="xnama" value="<?= $datas['nama'] ?>" class="form-control" id="inputUserName"  required>
                                              </div>
                                          </div>

                                          <div class="form-group">
                                           <label for="inputUserName" class="col-sm-4 control-label">Tanggal</label>
                                            <div class="col-sm-7">
                                              <div class="input-group date">
                                                <div class="input-group-addon">
                                                  <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="xtanggal" value="<?= $datas['tanggal'] ?>" class="form-control form-control-inline input-medium default-date-picker" id="datepicker2" placeholder="Contoh: 03-06-2020" required>
                                              </div>
                                            </div>
                                          </div>

                                          <div class="form-group">
                                              <label for="inputUserName" class="col-sm-4 control-label">Biaya</label>
                                              <div class="col-sm-7">
                                                <input type="text" name="xbiaya" value="<?= $datas['biaya'] ?>" class="form-control" id="inputUserName" placeholder="Contoh: 5000000" required>
                                              </div>
                                          </div>


                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary btn-flat" id="simpan">Update</button>
                                  </div>
                                  </form>
                              </div>
                          </div>
                      </div>
  

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('dokumen/hapus_dokumen') ?>/<?= $datas['idsistem'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->



        
<!--Modal Add Pengguna-->
        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'integrasi/simpan_integrasi'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                            <div class="form-group">
                                <label for="inputUserName" class="col-sm-4 control-label">Nama Kegiatan</label>
                                <div class="col-sm-7">
                                  <input type="text" name="xnama" class="form-control" id="inputUserName" placeholder="Contoh: Pengembangan Website" required>
                                </div>
                            </div>


                            <div class="form-group">
                             <label for="inputUserName" class="col-sm-4 control-label">Tanggal</label>
                              <div class="col-sm-7">
                                <div class="input-group date">
                                  <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                  </div>
                                  <input type="text" name="xtanggal" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off" formaction="yyyy-mm-dd" id="datepicker2" placeholder="Contoh: 03-06-2020" required>
                                </div>
                              </div>
                            </div>

                            <div class="form-group">
                                <label for="inputUserName" class="col-sm-4 control-label">Biaya</label>
                                <div class="col-sm-7">
                                  <input type="text" name="xbiaya" class="form-control" id="inputUserName" placeholder="Contoh: 5000000" required>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
		

	<!--Modal Edit Pengguna-->
 