
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Akuntansi</button>

        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Add Akuntansi</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('akuntansi/simpan_akuntansi') ?>" >
                <label>Jenis Akuntansi</label>
                <select class="form-control select2" id="inputSuccess" name="xjenis">
                    <option value=''>-Pilih Jenis Akuntan-</option>
                    <option value='Pemasukan'>-Pemasukan-</option>
                    <option value='Pengeluaran'>-Pengeluaran-</option>
                    
                </select>
                <br>
                <label>Nama Akuntansi</label>
                <input type="text" name="xnama" class="form-control" autocomplete="off" placeholder="Nama Akuntansi">
                <br>
                <label>Tanggal Akuntansi</label>
                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                <br>
                <label>Biaya Akuntansi</label>
                <input type="text" name="xjumlah" class="form-control" autocomplete="off" placeholder="Biaya Akuntansi">
                <br>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan datas -->





        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Barang Produksi</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal</th>
                    <th><i class="fa fa-bookmark"></i> Jumlah Barang</th>
                    <th><i class=" fa fa-edit"></i> Biaya</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $i) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $i['jenisakuntansi']  ?></td>
                    <td><?= $i['namaakuntansi'] ?></td>
                    <td class="center"><?= $i['tanggal'] ?></td>
                    <td><?= rupiah($i['Jumlah']) ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $i['idakuntan'] ?>"><i class="fa fa-pencil"></i> Ganti</a>
                          <div class="modal fade" id="ganti<?= $i['idakuntan'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title" id="myModalLabel">Add Produksi</h4>
                              </div>
                              <div class="modal-body">
                                <form method="POST" action="<?= base_url('akuntansi/update_akuntansi') ?>" >
                                  <label>Jenis Akuntansi</label>
                                  <select class="form-control select2" id="inputSuccess" name="xjenis">
                                      <option value=''>-Pilih Jenis Akuntan-</option>
                                      <option value='Pemasukan' <?= $i['jenisakuntansi'] == 'Pemasukan' ? "Selected" : "" ?>>-Pemasukan-</option>
                                      <option value='Pengeluaran' <?= $i['jenisakuntansi'] == 'Pengeluaran' ? "Selected" : "" ?>>-Pengeluaran-</option>
                                      
                                  </select>
                                  <br>
                                  <label>Nama Akuntansi</label>
                                  <input type="text" name="xnama" class="form-control" autocomplete="off" placeholder="Nama Akuntansi" value="<?= $i['namaakuntansi'] ?>">
                                  <br>
                                  <label>Tanggal Akuntansi</label>
                                  <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="<?= date("Y-m-d", strtotime($i['tanggal'])); ?>" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                                  <br>
                                  <label>Biaya Akuntansi</label>
                                  <input type="text" name="xjumlah" class="form-control" autocomplete="off" placeholder="Biaya Akuntansi" value="<?= $i['Jumlah'] ?>">
                                  <input type="hidden" name="xidakuntansi" value="<?= $i['idakuntan'] ?>">
                                  <br>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                  <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
                               </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      
                      <a class="btn btn-danger  btn-xs" href="<?= base_url('akuntansi/hapus_akuntansi') ?>/<?= $i['idakuntan'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel i -->





</body>
</html>