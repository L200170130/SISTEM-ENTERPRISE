
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Purchasing</button>

        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Add Purchasing</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('purchasing/simpan_purchasing') ?>" >
                <label>Nama Pembelian</label>
                <input type="text" name="xnama" class="form-control" autocomplete="off" placeholder="Nama Marketing">
                <br>
                <label>Tanggal Pembelian</label>
                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                <br>
                <label>Biaya Pembelian</label>
                <input type="text" name="xbiaya" class="form-control" autocomplete="off" placeholder="Biaya Marketing">
                <br>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan datas -->





        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Marketing</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal</th>
                    <th><i class=" fa fa-edit"></i> Biaya</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['namapembelian'] ?></td>
                    <td><?= $datas['tanggal'] ?></td>
                    <td><?= rupiah($datas['biaya']) ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idpembelian'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $datas['idpembelian'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myModalLabel">Ganti Data</h4>
                            </div>
                            <div class="modal-body">
                              <form action="<?= base_url('purchasing/update_purchasing') ?>/" method="POST">
                                <label>Nama Marketing</label>
                                <input type="text" name="xnama" class="form-control" autocomplete="off" placeholder="Nama Marketing" value="<?= $datas['namapembelian'] ?>">
                                <br>
                                <label>Tanggal</label>
                                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                                <br>
                                <label>Biaya Marketing</label>
                                <input type="text" name="xbiaya" class="form-control" autocomplete="off" placeholder="Biaya Marketing" value="<?= $datas['biaya'] ?>">
                                <br>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <input class='btn btn-primary' type='submit' name='edit' value='Ganti'>
                              <input type="hidden" name="xidpembelian" value="<?= $datas['idpembelian'] ?>">
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('purchasing/hapus_purchasing') ?>/<?= $datas['idpembelian'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->





</body>
</html>