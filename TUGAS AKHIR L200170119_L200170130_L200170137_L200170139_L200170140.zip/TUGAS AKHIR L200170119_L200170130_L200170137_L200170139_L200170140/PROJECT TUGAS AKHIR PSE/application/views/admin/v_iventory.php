
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Barang</button>

        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Add Barang</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('iventory/simpan_iventory') ?>" >
                <label>Nama Barang</label>
                <input type="text" name="xnama_barang" class="form-control" autocomplete="off" placeholder="Nama Barang">
                <br>
                <label>Harga Barang</label>
                <input type="text" name="xharga_barang" class="form-control" autocomplete="off" placeholder="Harga Barang">
                <br>
                <label>Stok</label>
                <input type="text" name="xstock_barang" class="form-control" autocomplete="off" placeholder="Stok">
                <br>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan datas -->





        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Barang</th>
                    <th><i class="fa fa-bookmark"></i> Harga Barang</th>
                    <th><i class=" fa fa-edit"></i> Stok</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['namabarang'] ?></td>
                    <td><?= rupiah($datas['hargabarang']) ?></td>
                    <td><?= $datas['stokbarang'] ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idbarang'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $datas['idbarang'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myModalLabel">Ganti Data</h4>
                            </div>
                            <div class="modal-body">
                              <form method="POST" action="<?= base_url('iventory/update_iventory') ?>" >
                              <label>Nama Barang</label>
                              <input type="text" name="xnama_barang" class="form-control" autocomplete="off" placeholder="Nama Barang" value="<?= $datas['namabarang'] ?>">
                              <br>
                              <label>Harga Barang</label>
                              <input type="text" name="xharga_barang" class="form-control" autocomplete="off" placeholder="Harga Barang" value="<?= $datas['hargabarang']?>">
                              <br>
                              <label>Stok</label>
                              <input type="text" name="xstock_barang" class="form-control" autocomplete="off" placeholder="Stok" value="<?= $datas['stokbarang'] ?>">
                              <br>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <input class='btn btn-primary' type='submit' name='edit' value='Ganti'>
                              <input type="hidden" name="xid_barang" value="<?= $datas['idbarang'] ?>">
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('iventory/hapus_iventory') ?>/<?= $datas['idbarang'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->


