
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Penggajian</button>


        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Karyawan</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal Gajian</th>
                    <th><i class=" fa fa-edit"></i> Gaji diterima</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['nama'] ?></td>
                    <td><?= $datas['tanggalgaji'] ?></td>
                    <td><?= $datas['gaji'] ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idpayroll'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                     <div class="modal fade" id="ganti<?= $datas['idpayroll'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                  <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                                      <h4 class="modal-title" id="myModalLabel">Edit Penggajian</h4>
                                  </div>
                                  <form class="form-horizontal" action="<?php echo base_url().'payroll/update_payroll'?>" method="post" enctype="multipart/form-data">
                                  <div class="modal-body">
                                              
                                          <div class="form-group">
                                              <div class="col-sm-7">
                                                <input type="hidden" name="xidpayroll" value="<?= $datas['idpayroll'] ?>">
                                              </div>
                                          </div>

                                          <div class="form-group">
                                          <label for="inputUserName" class="col-sm-4 control-label">Nama Karyawan</label>
                                          <div class="col-sm-7">
                                          <select class="form-control" name="xidkaryawan" id="inputUserName" required>
                                          <option value="<?= $datas['idkaryawan'] ?>"><?= $datas['nama'] ?></option>
                                          <?php 
                                          foreach($data1->result_array() as $ia) :
                                          ?>
                                            <option value="<?php echo $ia['idkaryawan']?>"><?= $ia['nama']?></option>
                                          <?php endforeach;?>
                                          </select>
                                              </div>
                                          </div>

                                          <div class="form-group">
                                           <label for="inputUserName" class="col-sm-4 control-label">Tanggal payroll</label>
                                            <div class="col-sm-7">
                                              <div class="input-group date">
                                                <div class="input-group-addon">
                                                  <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" name="xtanggal" value="<?= $datas['tanggalgaji'] ?>" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off" id="datepicker2" placeholder="Contoh: 03-06-2020" required>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                              <label for="inputUserName" class="col-sm-4 control-label">Gaji Diterima(Rp)</label>
                                              <div class="col-sm-7">
                                                <input type="text" name="xbiaya" value="<?= $datas['gaji'] ?>" class="form-control" id="inputUserName" placeholder="Contoh: 1000000" required>
                                              </div>
                                          </div>
                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary btn-flat" id="simpan">Update</button>
                                  </div>
                                  </form>
                              </div>
                          </div>
                      </div>
                      <a class="btn btn-danger  btn-xs" href="<?= base_url('payroll/hapus_payroll') ?>/<?= $datas['idpayroll'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->



<!--Modal Add Pengguna-->
        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add payroll</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'payroll/simpan_payroll'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                            <div class="form-group">
                            <label for="inputUserName" class="col-sm-4 control-label">Nama Karyawan</label>
                            <div class="col-sm-7">
                            <select class="form-control" name="xidkaryawan" id="inputUserName" required>
                            <option value="">No Selected</option>
                            <?php 
                            foreach($data1->result_array() as $ia) :
                            ?>
                            <option value="<?php echo $ia['idkaryawan']?>"><?php echo $ia['nama']?></option>
                            <?php endforeach;?>
                            </select>
                                </div>
                            </div>


                            </div>
                            <div class="form-group">
                             <label for="inputUserName" class="col-sm-4 control-label">Tanggal Penggajian</label>
                              <div class="col-sm-7">
                                <div class="input-group date">
                                  <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                  </div>
                                  <input type="text" name="xtanggal" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off" id="datepicker2" placeholder="Contoh: 03-06-2020" required>
                                </div>
                              </div>
                            </div>


                            <div class="form-group">
                                <label for="inputUserName" class="col-sm-4 control-label">Gaji Diterima(Rp)</label>
                                <div class="col-sm-7">
                                  <input type="text" name="xbiaya" class="form-control" id="inputUserName" required>
                                </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
		    