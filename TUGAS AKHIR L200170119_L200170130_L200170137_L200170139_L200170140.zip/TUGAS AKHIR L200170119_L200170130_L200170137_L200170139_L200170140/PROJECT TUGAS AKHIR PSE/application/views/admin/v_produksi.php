
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Produksi</button>

        <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Add Produksi</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('produksi/simpan_produksi') ?>" >
                <label>Nama Barang Produksi</label>
                <select class="form-control select2" id="inputSuccess" name="xidbarang">
                    <option value='0'>--Pilih Sepatu--</option>
                    <?php foreach ($data1->result_array() as $barang) : ?>
                      <option value='<?= $barang['idbarang'] ?>'> <?= $barang['namabarang'] ?> </option>
                    <?php endforeach ?>
                </select>
                <br>
                <label>Tanggal Produksi</label>
                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                <br>
                <label>Total Produksi</label>
                <input type="text" name="xtotalproduksi" class="form-control" autocomplete="off" placeholder="Biaya Marketing">
                <br>
                <label>Biaya Produksi</label>
                <input type="text" name="xbiayaproduksi" class="form-control" autocomplete="off" placeholder="Biaya Marketing">
                <br>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan datas -->





        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Barang Produksi</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal</th>
                    <th><i class="fa fa-bookmark"></i> Jumlah Barang</th>
                    <th><i class=" fa fa-edit"></i> Biaya</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['namabarang'] ?></td>
                    <td><?= $datas['tanggalproduksi'] ?></td>
                    <td class="center"><?= $datas['jumlahbarang'] ?></td>
                    <td><?= rupiah($datas['biayaproduksi']) ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idproduksi'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $datas['idproduksi'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myModalLabel">Ganti Data</h4>
                            </div>
                            <div class="modal-body">
                              <form action="<?= base_url('produksi/update_produksi') ?>/" method="POST">
                                <label>Nama Barang Produksi</label>
                                <select class="form-control select2" id="inputSuccess" name="xidbarang">
                                    <option value='0'>--Pilih Sepatu--</option>
                                    <?php foreach ($data1->result_array() as $barang) : ?>
                                      <option value='<?= $barang['idbarang'] ?>' <?= $datas['idbarang'] == $barang['idbarang'] ? "Selected" : "" ?> > <?= $barang['namabarang'] ?> </option>
                                    <?php endforeach ?>
                                </select>
                                <br>
                                <label>Tanggal</label>
                                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="<?= $datas['tanggalproduksi'] ?>" name="xtanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                                <br>
                                <label>Total Produksi</label>
                                <input type="text" name="xtotalproduksi" class="form-control" autocomplete="off" placeholder="Biaya Marketing" value="<?= $datas['jumlahbarang'] ?>">
                                <br>
                                <label>Biaya Produksi</label>
                                <input type="text" name="xbiayaproduksi" class="form-control" autocomplete="off" placeholder="Biaya Marketing" value="<?= $datas['biayaproduksi'] ?>">
                                <br>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <input class='btn btn-primary' type='submit' name='edit' value='Ganti'>
                              <input type="hidden" name="xidproduksi" value="<?= $datas['idproduksi'] ?>">
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('produksi/hapus_produksi') ?>/<?= $datas['idproduksi'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->





</body>
</html>