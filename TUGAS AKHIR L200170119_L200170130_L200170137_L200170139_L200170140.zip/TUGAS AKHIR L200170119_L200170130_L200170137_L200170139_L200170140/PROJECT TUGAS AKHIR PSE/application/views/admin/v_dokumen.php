
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#Add">Add Barang</button>




        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Jenis Dokumen</th>
                    <th><i class="fa fa-bookmark"></i> Nama Dokumen</th>
                    <th><i class=" fa fa-edit"></i> Link Download</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['jenisdokumen'] ?></td>
                    <td><?= $datas['namadokumen'] ?></td>
                    <td><a href="<?= $datas['link'] ?>">unduh</a></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['iddokumen'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $datas['iddokumen'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                      <div class="modal-dialog" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                                  <h4 class="modal-title" id="myModalLabel">Edit Dokumen <?= $datas['iddokumen'] ?></h4>
                              </div>
                              <form class="form-horizontal" action="<?php echo base_url().'dokumen/update_dokumen'?>" method="post" enctype="multipart/form-data">
                              <div class="modal-body">        
                                    <div class="form-group">
                                        <div class="col-sm-7">
                                            <input type="hidden" name="xid" value="<?= $datas['iddokumen'] ?>" class="form-control" id="inputUserName"  required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                    <label for="inputUserName" class="col-sm-4 control-label">Jenis Dokumen</label>
                                    <div class="col-sm-7">
                                    <select class="form-control" name="xjenis" id="inputUserName" required>
                                    <option value="<?= $datas['jenisdokumen'] ?>"><?= $datas['jenisdokumen'] ?></option>
                                    <option value="Masuk">Masuk</option>
                                    <option value="Keluar">Keluar</option>
                                    </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama Dokumen</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" value="<?= $datas['namadokumen'] ?>" class="form-control" id="inputUserName"  required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Link Dokumen</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xlink" value="<?= $datas['link'] ?>" class="form-control" id="inputUserName"  required>
                                        </div>
                                    </div>
                               
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                                  <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                              </div>
                              </form>
                          </div>
                      </div>
                  </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('dokumen/hapus_dokumen') ?>/<?= $datas['iddokumen'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->



            <!--Modal Add Pengguna-->
          <div class="modal fade" id="Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Dokumen</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'dokumen/simpan_dokumen'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                    <label for="inputUserName" class="col-sm-4 control-label">Jenis Dokumen</label>
                                    <div class="col-sm-7">
                                    <select class="form-control" name="xjenis" id="inputUserName" required>
                                    <option value="">No Selected</option>
                                    <option value="Masuk">Masuk</option>
                                    <option value="Keluar">Keluar</option>
                                    </select>
                                        </div>
                                    </div>
                                
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama Dokumen</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputUserName" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Link Dokumen</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xlink" class="form-control" id="inputUserName" required>
                                        </div>
                                    </div>
                                    

                               

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                    
                </div>
            </div>
        </div>

<!--Modal Edit Album-->
        