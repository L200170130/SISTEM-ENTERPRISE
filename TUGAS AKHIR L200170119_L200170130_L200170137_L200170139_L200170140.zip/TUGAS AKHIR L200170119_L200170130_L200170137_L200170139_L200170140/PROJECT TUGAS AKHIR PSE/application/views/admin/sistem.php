
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('username') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#in-pesanan">Tambah Pesanan</button>

        <div class="modal fade" id="in-pesanan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Tambah Pesanan</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('sistem') ?>" >
                <label>Pilih Sepatu</label>
                <select class="form-control select2" id="inputSuccess" name="sepatu">
                    <option value='0'>--Pilih Sepatu--</option>
                    <?php foreach ($databarang as $barang) : ?>
                      <option value='<?= $barang['idbarang'] ?>'> <?= $barang['namabarang'] ?> -- <?= $barang['hargabarang'] ?> -- <?= $barang['stokbarang'] ?> </option>
                    <?php endforeach ?>
                </select> 
                <br>
                <label>Qty</label>
                <select class="form-control" id="inputSuccess" name="qty">
                  <?php 
                    echo "<option value='0'> -- Berapa? -- </option>";
                      $jm = 1;
                      while ($jm <= 16) {
                        echo "<option value=".$jm."> ".$jm++." </option>";
                      }
                  
                   ?>
                    
                  
                </select> 
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan Pesanan -->





        <!-- Table Pesanan  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Pesanan</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Sepatu</th>
                    <th><i class="fa fa-bookmark"></i> Harga</th>
                    <th><i class=" fa fa-edit"></i> Qty</th>
                    <th><i class=" fa fa-money"> Total</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($datapesanan as $pesanan) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $pesanan['namabarang'] ?></td>
                    <td><?= $pesanan['harga'] ?></td>
                    <td><?= $pesanan['qty'] ?></td>
                    <td><?= $pesanan['total'] ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $pesanan['idorder'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $pesanan['idorder'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myModalLabel">Ganti Pesanan</h4>
                            </div>
                            <div class="modal-body">
                              <form action="<?= base_url('sistem') ?>" method="POST">
                              <label>Pilih Menu</label>
                              <select class="form-control" id="inputSuccess" name="sepatu">
                                <?php foreach ($databarang as $barang) : ?>
                                  <option value='<?= $barang['idbarang'] ?>' <?= $barang['namabarang'] == $pesanan['namabarang'] ? 'Selected' : "" ?>> <?= $barang['namabarang'] ?> -- <?= $barang['hargabarang'] ?> -- <?= $barang['stokbarang'] ?> </option>
                                <?php endforeach ?>
                              </select>
                            <br>
                            <label>Qty</label>
                            <select class="form-control" id="inputSuccess" name="qty">
                            <?php 
                                
                                $jm = 1;
                                while ($jm <= 15) { ?>
                                  <option value="<?= $jm ?>" <?= $jm == $pesanan['qty'] ? "Selected" : '' ?>> <?= $jm ?> </option>";
                                 
                                <?php
                                  $jm= $jm+1;
                                }
                              
                              ?>
                              </select>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <input class='btn btn-primary' type='submit' name='edit' value='Ganti'>
                              <input type="hidden" name="gid1" value="<?= $pesanan['idorder'] ?>">
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url() ?>sistem/hapus/<?= $pesanan['idorder'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  <?php 
                    $sum = $sum+$pesanan['total'] ;
                  ?>
                  <?php endforeach ?>
                  <tr>
                    <td>  </td>
                    <td> <b>TOTAL</b> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> <b><?= $sum ?></b> </td>
                    <td> </td>
                  </tr>
                </tbody>
      
              </table>
              <div class="row pt-2">
                  <div class="col-lg-11 pt-0">
                    <input class="btn f btn-theme02" type="submit" name="bayar" value="Bayar" id="swal-2" data-toggle="modal" data-target="#ibayar">
                  </div>

              </div>
              <br><br>
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel Pesanan -->




        <div class="modal fade" id="ibayar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Pembayaran</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="">
                <label> Total Bayar </label>
                <input class="form-control" id='total' name="Total" readonly value="<?php echo $sum; ?>" autocomplete="off"> <br>
                <label> Nominal </label>
                <input class="form-control" id='nominal' name="nominal" autocomplete="off"><br>
                <label> Kembalian </label>
                <input class="form-control" id='kembalian' name="kembalian" readonly autocomplete="off" ><br>
              </div>
                <!-- <input type="hidden" name="vT" id='n1' value="">
                <input type="hidden" name="vkem" id='n4'> -->
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class="btn btn-primary" type="submit" name="bayar" value="Bayar">
              </div>
              
            </form>
          </div>
        </div>
      </div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#total, #nominal").keyup(function() {
            var nominal  = $("#nominal").val();
            var total = $("#total").val();

            var kembalian = parseInt(total) - parseInt(nominal);
            $("#kembalian").val(kembalian);
        });
    });
</script>