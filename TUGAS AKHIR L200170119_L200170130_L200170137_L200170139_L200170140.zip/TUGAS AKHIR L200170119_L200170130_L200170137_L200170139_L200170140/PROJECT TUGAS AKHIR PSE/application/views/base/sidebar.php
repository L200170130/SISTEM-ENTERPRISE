    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.php" class="logo"><b>Sistem <span>Enterprise</span></b></a> 
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <ul class="nav top-menu">


        </ul>
      </div>

      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="<?= base_url('home') ?>/logout">Logout </a></li>
          <li><a class="logout" href=""><?php echo date("D, d  F  Y"); ?></a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <h5 class="centered"><?= $this->session->userdata('nama') ?></h5>
          <li class="mt">
            <a <?= $this->uri->segment('1') == 'dashboard' ? "class='active'" : ""; ?> href="<?= base_url('dashboard') ?>">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'sistem' ? "class='active'" : ""; ?> href="<?= base_url('sistem') ?>">
              <i class="fa fa-pencil-square"></i>
              <span>Sistem Penjualan</span>
              </a>
          </li>
   
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'marketing' ? "class='active'" : ""; ?> href="<?= base_url('marketing') ?>">
              <i class="fa fa-book"></i>
              <span>Marketing</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'purchasing' ? "class='active'" : ""; ?> href="<?= base_url('purchasing') ?>">
              <i class="fa fa-inbox"></i>
              <span>Purchasing</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'inventory' ? "class='active'" : ""; ?> href="<?= base_url('iventory') ?>">
              <i class="fa fa-cutlery"></i>
              <span>Inventory </span>
              <!-- <span class="label label-warning pull-right mail-info">3</span> -->
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'produksi' ? "class='active'" : ""; ?> href="<?= base_url('produksi') ?>">
              <i class="fa fa-th"></i>
              <span>Produksi</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'akuntansi' ? "class='active'" : ""; ?> href="<?= base_url('akuntansi') ?>">
              <i class="fa fa-th"></i>
              <span>Akuntansi</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'human' ? "class='active'" : ""; ?> href="<?= base_url('human') ?>">
              <i class="fa fa-th"></i>
              <span>Human Resource</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'payroll' ? "class='active'" : ""; ?> href="<?= base_url('payroll') ?>">
              <i class="fa fa-th"></i>
              <span>Payroll</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'dokumen' ? "class='active'" : ""; ?> href="<?= base_url('dokumen') ?>">
              <i class="fa fa-th"></i>
              <span>Dokumen</span>
              </a>
          </li>
          <li class="sub-menu">
            <a <?= $this->uri->segment('1') == 'integrasi' ? "class='active'" : ""; ?> href="<?= base_url('integrasi') ?>">
              <i class="fa fa-th"></i>
              <span>Integrasi Sistem</span>
              </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
 