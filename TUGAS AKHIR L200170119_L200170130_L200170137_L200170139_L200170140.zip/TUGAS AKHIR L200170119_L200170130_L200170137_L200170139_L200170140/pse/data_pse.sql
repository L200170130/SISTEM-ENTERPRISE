-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2020 at 04:29 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_pse`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounting`
--

CREATE TABLE `accounting` (
  `idakuntan` int(11) NOT NULL,
  `jenisakuntansi` varchar(255) NOT NULL,
  `namaakuntansi` varchar(255) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `Jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounting`
--

INSERT INTO `accounting` (`idakuntan`, `jenisakuntansi`, `namaakuntansi`, `tanggal`, `Jumlah`) VALUES
(13, 'Pengeluaran', 'Produksi Vans', '2020-04-03', 80000),
(15, 'Pengeluaran', 'Endorse Artis', '2020-04-14', 7000000),
(18, 'Pengeluaran', 'Gj.Pg Teguh Prasetyo', '2020-03-10', 3500000),
(21, 'Pengeluaran', 'Produksi Meja', '2020-01-16', 2224),
(22, 'Pemasukan', 'Investasi Masuk', '2020-04-17', 67676),
(24, 'Pengeluaran', 'Pengembangan Website', '2020-02-19', 7200000),
(25, 'Pengeluaran', 'Infrastructure Development', '2020-05-14', 7000000),
(26, 'Pengeluaran', 'Infrastructure Development', '2020-05-20', 7200000),
(27, 'Pengeluaran', 'Datacenter Development', '2020-06-02', 3500000),
(28, 'Pengeluaran', 'Iklan Youtube', '2020-06-18', 1500000),
(37, 'Pengeluaran', 'Produksi Adidas', '2020-05-13', 200000),
(38, 'Pemasukan', 'pak Johan', '2020-04-14', 345600),
(39, 'Pemasukan', 'Pak Bana', '06-07-2020', 35000),
(40, 'Pengeluaran', 'Pengiklanan Website', '06-24-2020', 550000);

-- --------------------------------------------------------

--
-- Table structure for table `dokumen`
--

CREATE TABLE `dokumen` (
  `iddokumen` int(11) NOT NULL,
  `jenisdokumen` varchar(255) NOT NULL,
  `namadokumen` varchar(100) NOT NULL,
  `link` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokumen`
--

INSERT INTO `dokumen` (`iddokumen`, `jenisdokumen`, `namadokumen`, `link`) VALUES
(1, 'Masuk', 'Return Pembelian', 'http://deluxeaccounting.com/download/accurate3tutorial/PURCHASE%20RETURN.pdf'),
(3, 'Keluar', 'Return Penjualan', 'http://deluxeaccounting.com/download/accurate4tutorial/Sales%20Return.pdf'),
(4, 'Masuk', 'Pajak Barang', 'http://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `human`
--

CREATE TABLE `human` (
  `idkaryawan` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `devisi` varchar(100) NOT NULL,
  `jabatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `human`
--

INSERT INTO `human` (`idkaryawan`, `nama`, `devisi`, `jabatan`) VALUES
(1, 'Ihsan Budiono L200170119', 'Human Resource', 'CO Devisi'),
(3, 'Ihsan Budiono L200170119', 'System Integration', 'Anggota Devisi'),
(5, 'Azzahra Salsabilla L200170130', 'Marketing', 'CO Devisi'),
(6, 'Azzahra Salsabilla L200170130', 'Document Management', 'Staff Operator'),
(7, 'Lail Nur Rachman L200170137', 'Iventory Control', 'Anggota Devisi'),
(8, 'Lail Nur Rachman L200170137', 'Pay role', 'CO Devisi'),
(9, 'Dita Denita Pramesti L200170139', 'Purchasing', 'Staff Operator'),
(10, 'Dita Denita Pramesti L200170139', 'Production', 'CO Devisi'),
(11, 'Puspita Purnamasari L200170140', 'Sales', 'CO Devisi'),
(12, 'Puspita Purnamasari L200170140', 'Accounting', 'Anggota Devisi');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `idbarang` int(11) NOT NULL,
  `hargabarang` int(11) NOT NULL,
  `stokbarang` int(11) NOT NULL,
  `namabarang` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`idbarang`, `hargabarang`, `stokbarang`, `namabarang`) VALUES
(2, 700000, 10, 'Superga'),
(5, 520000, 26, 'Converse'),
(6, 450000, 23, 'Adidas'),
(7, 560000, 14, 'League');

-- --------------------------------------------------------

--
-- Table structure for table `marketing`
--

CREATE TABLE `marketing` (
  `idmarketing` int(11) NOT NULL,
  `namamarketing` varchar(255) NOT NULL,
  `tanggal` varchar(40) NOT NULL,
  `biaya` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marketing`
--

INSERT INTO `marketing` (`idmarketing`, `namamarketing`, `tanggal`, `biaya`) VALUES
(2, 'iklan tv', '04-17-2020', 5000000),
(4, 'Endorse Artis', '06-25-2020', 7000000);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `idorder` int(11) NOT NULL,
  `barangid` int(11) NOT NULL,
  `harga` int(12) NOT NULL,
  `qty` int(5) NOT NULL,
  `total` int(20) NOT NULL,
  `tanggal` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `bayar` int(20) NOT NULL,
  `code` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `idpayroll` int(11) NOT NULL,
  `tanggalgaji` text NOT NULL,
  `gaji` int(11) NOT NULL,
  `idkaryawan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`idpayroll`, `tanggalgaji`, `gaji`, `idkaryawan`) VALUES
(1, '01-07-2020', 500000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `idpembelian` int(11) NOT NULL,
  `namapembelian` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `biaya` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`idpembelian`, `namapembelian`, `tanggal`, `biaya`) VALUES
(1, 'Pembelian Bahan Produksi', '24-06-2020', 70000000),
(4, 'Pembelian Perangkat', '06-02-2020', 300000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `idproduksi` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `jumlahbarang` int(11) NOT NULL,
  `tanggalproduksi` varchar(255) NOT NULL,
  `biayaproduksi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`idproduksi`, `idbarang`, `jumlahbarang`, `tanggalproduksi`, `biayaproduksi`) VALUES
(49, 6, 5, '06-16-2020', 200000);

-- --------------------------------------------------------

--
-- Table structure for table `sistemintegrasi`
--

CREATE TABLE `sistemintegrasi` (
  `idsistem` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `biaya` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sistemintegrasi`
--

INSERT INTO `sistemintegrasi` (`idsistem`, `nama`, `tanggal`, `biaya`) VALUES
(1, 'Pengembangan Website', '17-06-2020', 7200000),
(3, 'Infrastructure Development', '03-30-2020', 9200000),
(4, 'Datacenter Development', '25-06-2020', 3500000),
(5, 'Pengiklanan Website', '06-24-2020', 550000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_inbox`
--

CREATE TABLE `tbl_inbox` (
  `inbox_id` int(11) NOT NULL,
  `inbox_nama` varchar(40) DEFAULT NULL,
  `inbox_email` varchar(60) DEFAULT NULL,
  `inbox_kontak` varchar(20) DEFAULT NULL,
  `inbox_pesan` text DEFAULT NULL,
  `inbox_tanggal` timestamp NULL DEFAULT current_timestamp(),
  `inbox_status` int(11) DEFAULT 1 COMMENT '1=Belum dilihat, 0=Telah dilihat'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengguna`
--

CREATE TABLE `tbl_pengguna` (
  `pengguna_id` int(11) NOT NULL,
  `pengguna_nama` varchar(50) DEFAULT NULL,
  `pengguna_moto` varchar(100) DEFAULT NULL,
  `pengguna_jenkel` varchar(2) DEFAULT NULL,
  `pengguna_username` varchar(30) DEFAULT NULL,
  `pengguna_password` varchar(35) DEFAULT NULL,
  `pengguna_tentang` text DEFAULT NULL,
  `pengguna_email` varchar(50) DEFAULT NULL,
  `pengguna_nohp` varchar(20) DEFAULT NULL,
  `pengguna_facebook` varchar(35) DEFAULT NULL,
  `pengguna_twitter` varchar(35) DEFAULT NULL,
  `pengguna_linkdin` varchar(35) DEFAULT NULL,
  `pengguna_google_plus` varchar(35) DEFAULT NULL,
  `pengguna_status` int(2) DEFAULT 1,
  `pengguna_level` varchar(3) DEFAULT NULL,
  `pengguna_register` timestamp NULL DEFAULT current_timestamp(),
  `pengguna_photo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengguna`
--

INSERT INTO `tbl_pengguna` (`pengguna_id`, `pengguna_nama`, `pengguna_moto`, `pengguna_jenkel`, `pengguna_username`, `pengguna_password`, `pengguna_tentang`, `pengguna_email`, `pengguna_nohp`, `pengguna_facebook`, `pengguna_twitter`, `pengguna_linkdin`, `pengguna_google_plus`, `pengguna_status`, `pengguna_level`, `pengguna_register`, `pengguna_photo`) VALUES
(1, 'Ihsan Budiono', 'Just do it', 'L', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'I am a mountainner. to me mountainerring is a life', 'fikrifiver97@gmail.com', '081277159401', 'facebook.com/m_fikri_setiadi', 'twitter.com/fiver_fiver', '', '', 1, '1', '2016-09-03 06:07:55', '1aa9ff5088173edccb446df1de95607c.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_bayar` int(50) NOT NULL,
  `uang` int(50) NOT NULL,
  `kembalian` int(50) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `code`, `user_id`, `total_bayar`, `uang`, `kembalian`, `tanggal`) VALUES
(1, 'LEITBZCFA', 1, 260000, 300000, -40000, '2020-06-26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounting`
--
ALTER TABLE `accounting`
  ADD PRIMARY KEY (`idakuntan`);

--
-- Indexes for table `dokumen`
--
ALTER TABLE `dokumen`
  ADD PRIMARY KEY (`iddokumen`);

--
-- Indexes for table `human`
--
ALTER TABLE `human`
  ADD PRIMARY KEY (`idkaryawan`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`idbarang`);

--
-- Indexes for table `marketing`
--
ALTER TABLE `marketing`
  ADD PRIMARY KEY (`idmarketing`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`idorder`),
  ADD KEY `orders_ibfk_1` (`barangid`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`idpayroll`),
  ADD KEY `idkaryawan` (`idkaryawan`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`idpembelian`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`idproduksi`),
  ADD KEY `idbarang` (`idbarang`) USING BTREE;

--
-- Indexes for table `sistemintegrasi`
--
ALTER TABLE `sistemintegrasi`
  ADD PRIMARY KEY (`idsistem`);

--
-- Indexes for table `tbl_inbox`
--
ALTER TABLE `tbl_inbox`
  ADD PRIMARY KEY (`inbox_id`);

--
-- Indexes for table `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  ADD PRIMARY KEY (`pengguna_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounting`
--
ALTER TABLE `accounting`
  MODIFY `idakuntan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `dokumen`
--
ALTER TABLE `dokumen`
  MODIFY `iddokumen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `human`
--
ALTER TABLE `human`
  MODIFY `idkaryawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `idbarang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `marketing`
--
ALTER TABLE `marketing`
  MODIFY `idmarketing` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `idorder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `idpayroll` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `idpembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `idproduksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `sistemintegrasi`
--
ALTER TABLE `sistemintegrasi`
  MODIFY `idsistem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_inbox`
--
ALTER TABLE `tbl_inbox`
  MODIFY `inbox_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  MODIFY `pengguna_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`barangid`) REFERENCES `inventory` (`idbarang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payroll`
--
ALTER TABLE `payroll`
  ADD CONSTRAINT `payroll_ibfk_1` FOREIGN KEY (`idkaryawan`) REFERENCES `human` (`idkaryawan`) ON UPDATE CASCADE;

--
-- Constraints for table `produksi`
--
ALTER TABLE `produksi`
  ADD CONSTRAINT `produksi_ibfk_1` FOREIGN KEY (`idbarang`) REFERENCES `inventory` (`idbarang`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
