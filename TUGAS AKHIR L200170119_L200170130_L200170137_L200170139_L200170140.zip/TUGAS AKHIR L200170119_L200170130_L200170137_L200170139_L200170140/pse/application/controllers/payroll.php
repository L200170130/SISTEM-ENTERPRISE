<?php
class payroll extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_payroll');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_payroll->get_all_payroll();
		$x['data1']=$this->m_payroll->get_all_humandata();
		$x['base'] = 'admin/v_payroll';
		$this->load->view('base/base',$x);
	}

 
	function simpan_payroll(){
		$tanggal=$this->input->post('xtanggal');
		$idkaryawan=$this->input->post('xidkaryawan');		
		$biaya=$this->input->post('xbiaya');
		$this->m_payroll->simpan_payroll($tanggal,$idkaryawan,$biaya);
		$this->m_payroll->simpan_akuntansi($tanggal,$idkaryawan,$biaya);
		echo $this->session->set_flashdata('msg','success');
		redirect('payroll');
	}

	function update_payroll(){
		$idpayroll=strip_tags($this->input->post('xidpayroll'));
		$tanggal=$this->input->post('xtanggal');
		$idkaryawan=$this->input->post('xidkaryawan');		
		$biaya=$this->input->post('xbiaya');
		$this->m_payroll->update_payroll($idpayroll,$tanggal,$idkaryawan,$biaya);
		echo $this->session->set_flashdata('msg','info');
		redirect('payroll');
	}
	function hapus_payroll($id=''){
		$this->m_payroll->hapus_payroll($id);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('payroll');
	}

}