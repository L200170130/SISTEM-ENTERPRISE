<?php
class Purchasing extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_purchasing');
	}


	function index(){
		$x['data']=$this->m_purchasing->get_all_purchasing()->result_array();
		$x['base']= 'admin/v_purchasing';
		$this->load->view('base/base', $x);
	}
	
	// perintah php untuk akses ke database
 
	function simpan_purchasing(){
	 	$nama=$this->input->post('xnama');
	 	$tanggal=$this->input->post('xtanggal');
	 	$biaya=$this->input->post('xbiaya');
		$this->m_purchasing->simpan_purchasing($nama,$tanggal,$biaya);
		$this->m_purchasing->simpan_akuntansi($nama,$tanggal,$biaya);
		redirect('purchasing');
	}
	
	function update_purchasing(){
		$idpembelian=strip_tags($this->input->post('xidpembelian'));
	 	$nama=$this->input->post('xnama');
	 	$tanggal=$this->input->post('xtanggal');
	 	$biaya=$this->input->post('xbiaya');
		$this->m_purchasing->update_purchasing($idpembelian,$nama,$tanggal,$biaya);
		redirect('purchasing');
	}

	function hapus_purchasing($id=''){
		$this->m_purchasing->hapus_purchasing($id);
		redirect('purchasing');
	}

}