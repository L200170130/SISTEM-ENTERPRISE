<?php
class Iventory extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_iventory');
	}


	function index(){
		$x['data']=$this->m_iventory->get_all_iventory();
		$x['base']='admin/v_iventory';
		$this->load->view('base/base',$x);
	}
	
	// perintah php untuk akses ke database

	function simpan_iventory(){
		$namabarang=strip_tags($this->input->post('xnama_barang'));
		$hargabarang=strip_tags($this->input->post('xharga_barang'));
		$stokbarang=strip_tags($this->input->post('xstock_barang'));
		$this->m_iventory->simpan_iventory($namabarang,$hargabarang,$stokbarang);
		redirect('iventory');
	}
	
	function update_iventory(){
		$idbarang=strip_tags($this->input->post('xid_barang'));
		$namabarang=strip_tags($this->input->post('xnama_barang'));
		$hargabarang=strip_tags($this->input->post('xharga_barang'));
		$stokbarang=strip_tags($this->input->post('xstock_barang'));
		$this->m_iventory->update_iventory($idbarang,$namabarang,$hargabarang,$stokbarang);
		redirect('iventory');
	}

	function hapus_iventory($id=''){
		$this->m_iventory->hapus_iventory($id);
		redirect('iventory');
	}

}