<?php
class Human extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_human');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_human->get_all_human();
		$x['base']='admin/v_human';
		$this->load->view('base/base',$x);
	}


	function simpan_human(){
		$nama=$this->input->post('xnama');		
		$devisi=$this->input->post('xdevisi');
		$jabatan=$this->input->post('xjabatan');		
		$this->m_human->simpan_human($nama,$devisi,$jabatan);
		echo $this->session->set_flashdata('msg','success');
		redirect('human');
	}

	function update_human(){
		$idkaryawan=strip_tags($this->input->post('xidkaryawan'));
		$nama=$this->input->post('xnama');		
		$devisi=$this->input->post('xdevisi');
		$jabatan=$this->input->post('xjabatan');		
		$this->m_human->update_human($idkaryawan,$nama,$devisi,$jabatan);
		echo $this->session->set_flashdata('msg','info');
		redirect('human');
	}
	function hapus_human($id=''){
		
		$this->m_human->hapus_human($id);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('human');
	}

}