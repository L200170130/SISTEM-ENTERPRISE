<?php 

	$this->load->view('base/header');
	$this->load->view('base/sidebar');
	$this->load->view($base);
	$this->load->view('base/footer');




 ?>