
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#in-datas">Tambah Marketing</button>

        <div class="modal fade" id="in-datas" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title" id="myModalLabel">Tambah Marketing</h4>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= base_url('marketing') ?>" >
                <label>Nama Marketing</label>
                <input type="text" name="nama" class="form-control" autocomplete="off" placeholder="Nama Marketing">
                <br>
                <label>Tanggal</label>
                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" name="tanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                <br>
                <label>Biaya Marketing</label>
                <input type="text" name="biaya" class="form-control" autocomplete="off" placeholder="Biaya Marketing">
                <br>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <input class='btn btn-primary' type='submit' name='tambah' value='Tambahkan'>
             </div>
            </form>
          </div>
        </div>
      </div>
        <!-- Batas Form masukan datas -->





        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Marketing</th>
                    <th><i class="fa fa-bookmark"></i> Tanggal</th>
                    <th><i class=" fa fa-edit"></i> Biaya</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['namamarketing'] ?></td>
                    <td><?= $datas['tanggal']?></td>
                    <td><?= rupiah($datas['biaya']) ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idmarketing'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

                      <div class="modal fade" id="ganti<?= $datas['idmarketing'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myModalLabel">Ganti Data</h4>
                            </div>
                            <div class="modal-body">
                              <form action="<?= base_url('marketing') ?>/" method="POST">
                                <label>Nama Marketing</label>
                                <input type="text" name="nama" class="form-control" autocomplete="off" placeholder="Nama Marketing" value="<?= $datas['namamarketing'] ?>">
                                <br>
                                <label>Tanggal</label>
                                <input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="<?= $datas['tanggal'] ?>" name="tanggal" autocomplete="off" placeholder="Contoh: 03-10-2019">
                                <br>
                                <label>Biaya Marketing</label>
                                <input type="text" name="biaya" class="form-control" autocomplete="off" placeholder="Biaya Marketing" value="<?= $datas['biaya'] ?>">
                                <br>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <input class='btn btn-primary' type='submit' name='edit' value='Ganti'>
                              <input type="hidden" name="gid1" value="<?= $datas['idmarketing'] ?>">
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('marketing') ?>/hapus/<?= $datas['idmarketing'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->





<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

    $('#datepicker').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('#datepicker2').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('.datepicker3').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('.datepicker4').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $(".timepicker").timepicker({
      showInputs: true
    });

  });
</script>
<?php if($this->session->flashdata('msg')=='error'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Error',
                    text: "Password dan Ulangi Password yang Anda masukan tidak sama.",
                    showHideTransition: 'slide',
                    icon: 'error',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FF4859'
                });
        </script>
    
    <?php elseif($this->session->flashdata('msg')=='success'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "marketing Berhasil disimpan ke database.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='info'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: "marketing berhasil di update",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='success-hapus'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "marketing Berhasil dihapus.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php else:?>

    <?php endif;?>
</body>
</html>