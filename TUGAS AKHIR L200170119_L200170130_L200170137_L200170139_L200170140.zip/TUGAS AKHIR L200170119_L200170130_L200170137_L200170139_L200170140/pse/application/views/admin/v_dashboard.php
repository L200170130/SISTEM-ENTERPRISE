<br><br>
    <!-- Main content -->
    <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Anda sekarang berada di halaman Administrator.</div><br>
    <!-- /.content -->
    <section class="content">
      <h2>Selamat Datang di Sistem Enterprise Perusahaan Sepatu "MARS"</h2>
    </section>
