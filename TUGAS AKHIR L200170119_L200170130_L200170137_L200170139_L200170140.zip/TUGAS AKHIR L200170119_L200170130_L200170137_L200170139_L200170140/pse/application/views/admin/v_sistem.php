<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sistem Enterprise | Sistem Penjualan</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css'?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css'?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/AdminLTE.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.css'?>">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datepicker/datepicker3.css'?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/skins/_all-skins.min.css'?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.css'?>"/>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php 
    $this->load->view('admin/v_header');
  ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">Menu Utama</li>
        <li>
          <a href="<?php echo base_url().'dashboard'?>">
            <i class="fa fa-home"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li class="active">
          <a href="<?php echo base_url().'sistem'?>">
            <i class="fa fa-calendar"></i> <span>Sistem Penjualan</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li >
          <a href="<?php echo base_url().'marketing'?>">
            <i class="fa fa-calendar"></i> <span>Marketing</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'purchasing'?>">
            <i class="fa fa-volume-up"></i> <span>Purchasing</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'iventory'?>">
            <i class="fa fa-volume-up"></i> <span>Inventory</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

        <li>
          <a href="<?php echo base_url().'produksi'?>">
            <i class="fa fa-volume-up"></i> <span>Produksi</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'akuntansi'?>">
            <i class="fa fa-volume-up"></i> <span>Akuntansi</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'human'?>">
            <i class="fa fa-volume-up"></i> <span>Human Resource</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

        <li>
          <a href="<?php echo base_url().'payroll'?>">
            <i class="fa fa-volume-up"></i> <span>Payroll</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'dokumen'?>">
            <i class="fa fa-volume-up"></i> <span>Dokumen</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
       <li >
          <a href="<?php echo base_url().'integrasi'?>">
            <i class="fa fa-volume-up"></i> <span>Integrasi Sistem</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url().'administrator/logout'?>">
            <i class="fa fa-sign-out"></i> <span>Sign Out</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>
       
      </ul>

    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sistem Penjualan
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Sistem Penjualan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
          <div class="box">
          
	<div class="container">
		<div class="col-md-12 col-md-offset-1">
		  <hr/>
			<form class="form-horizontal" id="form_transaksi">

        <div class="form-group">
          <label class="control-label col-xs-3" >No</label>
          <div class="col-xs-9">
              <input name="no" id="no" class="form-control" type="text"  style="width:335px;" readonly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Kode Barang</label>
          <div class="col-xs-9">
            <select name="idbarang" id="idbarang" class="form-control" style="width:335px;">
              <option value="">Kode Barang...</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Nama Barang</label>
          <div class="col-xs-9">
              <input name="namabarang" id="namabarang"class="form-control" type="text" placeholder="Nama Barang..." style="width:335px;" readonly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Harga</label>
          <div class="col-xs-9">
              <input name="hargabarang" id="hargabarang"class="form-control" type="text" placeholder="Harga..." style="width:335px;" readonly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-xs-3" >Jumlah Barang</label>
          <div class="col-xs-9">
            <input type="number" class="form-control" style="width:335px;" id="jumlahbarang" min="0" name="jumlah_barang" placeholder="Isi qty...">
          </div>
        </div>

        <div class="form-group">
            <label class="control-label col-xs-3" >Sub Total</label>
            <div class="col-xs-9">
                <input name="subtotal" id="subtotal" class="form-control" type="text"  style="width:335px;" readonly="readonly">
            </div>
        </div>

        <div class="form-group">
          <div class="col-md-offset-3 col-md-3">
            <button type="button" class="btn btn-primary" id="add_data" ><i class="fa fa-cart-plus"></i> Tambah</button>
          </div>
        </div>

			</form>
		</div>
	</div>


  <table id="table_transaksi" class="table table-striped table-bordered">
    <thead>
      <tr>
          <th>No#</th>
          <th>Id Barang</th>
          <th>Nama Barang</th>
          <th>Harga</th>
          <th>Quantity</th>
          <th>Sub-Total</th>
      </tr>
    </thead>
    <tbody>
    </tbody>
  </table>
  
  <div class="form-group">
    <label class="control-label col-xs-3" >Total Belanja</label>
    <div class="col-xs-9">
        <input name="total" id="total" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-xs-3" >Tunai</label>
    <div class="col-xs-9">
        <input name="tunai" id="tunai" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-xs-3" >Kembalian</label>
    <div class="col-xs-9">
        <input name="kembalian" id="kembalian" class="form-control" type="text"  style="width:335px;">
    </div>
  </div>
  
  <!-- <div class="form-group">
    <div class="col-md-offset-3 col-md-3">
      <button type="button" class="btn btn-primary" id="add_data2" ><i class="fa fa-cart-plus"></i> Tambah</button>
    </div>
  </div> -->




  <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      var totalbelanja = 0;
      $('#idbarang').on('input',function(){
        var idbarang=$(this).val();
        $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/sistem/get_barang')?>",
          dataType : "JSON",
          data : {id: idbarang},
          cache:false,
          success: function(data){
            $.each(data,function(idbarang, namabarang, hargabarang){
              $('[name="namabarang"]').val(data.namabarang);
              $('[name="hargabarang"]').val(data.hargabarang);
            });
          }
        });
        return false;
      });


      $( "#jumlahbarang").on("keyup change",function() {
        var sum = 0;
        var hargabarang  = $("#hargabarang").val();
        var jumlahbarang = $("#jumlahbarang").val();
        
        var subtotal = parseInt(hargabarang) * parseInt(jumlahbarang);
        $("#subtotal").val(subtotal);

      });


      $("#tunai").on("keyup change", function(){
        var total = $("#total").val();
        var tunai = $("#tunai").val();
        var kembalian = parseInt(tunai) - parseInt(total);
        $("#kembalian").val(kembalian);
      });

      var set_number= function(){
        var table_len = $('#table_transaksi tbody tr').length+1;
        $('#no').val(table_len);
      }
      set_number();

      $('#add_data').click(function(){
        var no = $('#no').val();
        var kodebarang = $('#idbarang').val();
        var namabarang = $('#namabarang').val();
        var hargabarang = $('#hargabarang').val();
        var jumlahbarang = $('#jumlahbarang').val();
        var subtotal = $('#subtotal').val();

        $('#table_transaksi tbody:last-child').append(
          '<tr>'+
              '<td>'+no+'</td>'+
              '<td>'+kodebarang+'</td>'+
              '<td>'+namabarang+'</td>'+
              '<td>'+hargabarang+'</td>'+
              '<td>'+jumlahbarang+'</td>'+
              '<td>'+subtotal+'</td>'+
          '</tr>'
        );

        totalbelanja += parseInt(subtotal);
        $("#total").val(totalbelanja);

        $('#no').val('');
        $('#idbarang').val('');
        $('#namabarang').val('');
        $('#hargabarang').val('');
        $('#jumlahbarang').val('');
        $('#subtotal').val('');

        set_number();
      });

    });
        
  </script>
            <!-- /.box-header -->
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2020 <a href="">Sistem Enterprise</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->	
	


<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url().'assets/plugins/jQuery/jquery-2.2.3.min.js'?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js'?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url().'assets/plugins/datatables/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.min.js'?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url().'assets/plugins/slimScroll/jquery.slimscroll.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datepicker/bootstrap-datepicker.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.js'?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url().'assets/plugins/fastclick/fastclick.js'?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url().'assets/dist/js/app.min.js'?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url().'assets/dist/js/demo.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.js'?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

    $('#datepicker').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('#datepicker2').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('.datepicker3').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $('.datepicker4').datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy'
    });
    $(".timepicker").timepicker({
      showInputs: true
    });

  });
</script>
<?php if($this->session->flashdata('msg')=='error'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Error',
                    text: "Password dan Ulangi Password yang Anda masukan tidak sama.",
                    showHideTransition: 'slide',
                    icon: 'error',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FF4859'
                });
        </script>
    
    <?php elseif($this->session->flashdata('msg')=='success'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "marketing Berhasil disimpan ke database.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='info'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: "marketing berhasil di update",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='success-hapus'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "marketing Berhasil dihapus.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php else:?>

    <?php endif;?>
</body>
</html>