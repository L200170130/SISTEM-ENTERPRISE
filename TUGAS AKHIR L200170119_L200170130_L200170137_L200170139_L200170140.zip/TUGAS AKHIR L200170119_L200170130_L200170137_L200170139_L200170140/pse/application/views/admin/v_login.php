

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Ihsan Budiono">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>SEPATU MARS</title>

  <!-- Favicons -->
  <link href="<?= base_url('assets/') ?>/img/favicon.png" rel="icon">
  <link href="<?= base_url('assets/') ?>/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?= base_url('assets/') ?>/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="<?= base_url('assets/') ?>/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="<?= base_url('assets/') ?>/css/style.css" rel="stylesheet">
  <link href="<?= base_url('assets/') ?>/css/style-responsive.css" rel="stylesheet">
</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

  <div id="login-page">
    <div class="container">
      <?= $this->session->flashdata('pesan'); ?>
      <form class="form-login" action="<?= base_url() ?>administrator/auth" method="POST">
        <h2 class="form-login-heading">MARS</h2>
        <div class="login-wrap">
          <input type="text" class="form-control" name="username" placeholder="Username" autofocus autocomplete="off"value="<?= set_value('username'); ?>"><?= form_error('username', '<small class="text-danger">', '</small>'); ?>
          <br>
          <input type="password" class="form-control" name="password" placeholder="Password" autocomplete="off">
          <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
          <br><br>
          <input type="submit" name="submit" class="btn btn-theme btn-block" value="LOGIN">
          <hr>


        </div>

      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?= base_url('assets/') ?>//lib/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/') ?>//lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="<?= base_url('assets/') ?>//lib/jquery.backstretch.min.js"></script>

</body>

</html>
