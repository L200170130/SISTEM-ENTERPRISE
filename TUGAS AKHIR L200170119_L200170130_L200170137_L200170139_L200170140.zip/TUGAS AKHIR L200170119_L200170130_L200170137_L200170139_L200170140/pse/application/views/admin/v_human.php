
            <br>
        <div class="alert alert-success"><b>Selamat Datang <?= $this->session->userdata('nama') ?>!</b> Kamu sekarang ada dihalaman Administrator.</div>

<!-- Letakkan Konten anda disini!! -->
        <button class="btn btn-info" data-toggle="modal" data-target="#myModal">Add Human Resource</button>






        <!-- Table datas  -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data</h4>
                <hr>
                <thead>
                  <tr>
                    <th></th>
                    <th><i class="fa fa-bars"></i> No.</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Barang</th>
                    <th><i class="fa fa-bookmark"></i> Harga Barang</th>
                    <th><i class=" fa fa-edit"></i> Stok</th>
                    <th><i class="fa fa-gear"> Action</i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sum = 0; $no=1; foreach ($data->result_array() as $datas) :?>
                  <tr>
                    <td></td>
                    <td><?= $no++ ?></td>
                    <td><?= $datas['nama'] ?></td>
                    <td><?= $datas['devisi'] ?></td>
                    <td><?= $datas['jabatan'] ?></td>
                    
                    <td>
                      <a class="btn btn-success  btn-xs" data-toggle="modal" data-target="#ganti<?= $datas['idkaryawan'] ?>"><i class="fa fa-pencil"></i> Ganti</a>

        <div class="modal fade" id="ganti<?= $datas['idkaryawan'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Human Resource</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'human/update_human'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                            <div class="form-group">
                                <div class="col-sm-7">
                                  <input type="hidden" name="xidkaryawan" value="<?= $datas['idkaryawan'] ?>">
                                </div>
                            </div>


                          <div class="form-group">
                                <label for="inputUserName" class="col-sm-4 control-label">Nama Karyawan</label>
                                <div class="col-sm-7">
                                  <input type="text" name="xnama" value="<?= $datas['nama'] ?>" class="form-control" id="inputUserName" placeholder="Contoh: 1000" required>
                                </div>
                            </div>

                            <div class="form-group">
                            <label for="inputUserName" class="col-sm-4 control-label">Devisi</label>
                            <div class="col-sm-7">
                            <select class="form-control" name="xdevisi" id="inputUserName" required>
                            <option value="<?= $datas['devisi'] ?>"><?= $datas['devisi'] ?></option>
                            <option value="Marketing">Marketing</option>
                            <option value="Sales">Sales</option>
                            <option value="Purchasing">Purchasing</option>
                            <option value="Iventory Control">Iventory Control</option>
                            <option value="Accounting">Accounting</option>
                            <option value="Production">Production</option>
                            <option value="Human Resource">Human Resource</option>
                            <option value="Pay role">Pay role</option>
                            <option value="Document Management">Document Management</option>
                            <option value="System Integration">System Integration</option>
                            </select>
                                </div>
                            </div>


                            <div class="form-group">
                            <label for="inputUserName" class="col-sm-4 control-label">Jabatan</label>
                            <div class="col-sm-7">
                            <select class="form-control" name="xjabatan" id="inputUserName" required>
                            <option value="<?= $datas['jabatan'] ?>"><?= $datas['jabatan'] ?></option>
                            <option value="CO Devisi">CO Devisi</option>
                            <option value="Anggota Devisi">Anggota Devisi</option>
                            <option value="Staff Operator">Staff Operator</option>
                            </select>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Update</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

                      <a class="btn btn-danger  btn-xs" href="<?= base_url('human/hapus_human') ?>/<?= $datas['idkaryawan'] ?>"><i class="fa fa-trash-o"></i> Hapus</a>
                    </td>
                  </tr>
                  
                  <?php endforeach ?>
                  
                </tbody>
      
              </table>
              
              
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>

        <!-- Batas Tabel datas -->

<!--Modal Add Pengguna-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Human Resource</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'human/simpan_human'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                            <div class="form-group">
                                <label for="inputUserName" class="col-sm-4 control-label">Nama Karyawan</label>
                                <div class="col-sm-7">
                                  <input type="text" name="xnama" class="form-control" id="inputUserName" required>
                                </div>
                              </div>                      
                                
                            <div class="form-group">
                            <label for="inputUserName" class="col-sm-4 control-label">Devisi</label>
                            <div class="col-sm-7">
                            <select class="form-control" name="xdevisi" id="inputUserName" required>
                            <option value="">No Selected</option>
                            <option value="Marketing">Marketing</option>
                            <option value="Sales">Sales</option>
                            <option value="Purchasing">Purchasing</option>
                            <option value="Iventory Control">Iventory Control</option>
                            <option value="Accounting">Accounting</option>
                            <option value="Production">Production</option>
                            <option value="Human Resource">Human Resource</option>
                            <option value="Pay role">Pay role</option>
                            <option value="Document Management">Document Management</option>
                            <option value="System Integration">System Integration</option>
                            </select>
                                </div>
                            </div>

                            <div class="form-group">
                            <label for="inputUserName" class="col-sm-4 control-label">Jabatan</label>
                            <div class="col-sm-7">
                            <select class="form-control" name="xjabatan" id="inputUserName" required>
                            <option value="">No Selected</option>
                            <option value="CO Devisi">CO Devisi</option>
                            <option value="Anggota Devisi">Anggota Devisi</option>
                            <option value="Staff Operator">Staff Operator</option>
                            </select>
                                </div>
                            </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                  </div>
                    </form>
                </div>
            </div>
        </div>
