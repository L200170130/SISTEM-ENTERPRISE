<?php 
class M_dokumen extends CI_Model{

	function get_all_dokumen(){
		$hsl=$this->db->query("SELECT * FROM dokumen");
		return $hsl;
	}

	function simpan_dokumen($jenis,$nama,$link){
	 	$hsl=$this->db->query("INSERT INTO dokumen (iddokumen,jenisdokumen,namadokumen,link) VALUES (null,'$jenis','$nama','$link')");
		return $hsl;
	}

	function update_dokumen($id,$jenis,$nama,$link){
	 	$hsl=$this->db->query("UPDATE dokumen SET iddokumen='$id',jenisdokumen='$jenis',namadokumen='$nama',link='$link' WHERE iddokumen='$id'");
	 	return $hsl;
	}
	
    function hapus_dokumen($id){
	 	$hsl=$this->db->query("DELETE FROM dokumen WHERE iddokumen='$id'");
	 	return $hsl;
	}

} 