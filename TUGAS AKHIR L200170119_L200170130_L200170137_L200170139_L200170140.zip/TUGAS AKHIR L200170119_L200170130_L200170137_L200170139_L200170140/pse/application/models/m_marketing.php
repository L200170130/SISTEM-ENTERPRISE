<?php
class M_marketing extends CI_Model{

	function get_all_marketing($id = null)
	{
		if ($id != null) {
    		$this->db->where('idbarang', $id);
    	}
        return $this->db->get('marketing')->result_array();
	}

	function simpan_marketing(){

	 	$data = $this->input->post(null, true);
		$params = [
			'namamarketing' => $data['nama'],
			'tanggal' => $data['tanggal'],
			'biaya' => $data['biaya'],
		];
		$this->db->insert('marketing', $params);
	}
  
	function simpan_akuntansi(){

	 	$data = $this->input->post(null, true);
		$params = [
			'jenisakuntansi' => 'Pengeluaran',
			'namaakuntansi' => $data['nama'],
			'tanggal' => $data['tanggal'],
			'Jumlah' => $data['biaya'],
		];
		$this->db->insert('accounting', $params);
	}

	function update_marketing(){

	 	$data = $this->input->post(null, true);
		$params = [
			'namamarketing' => $data['nama'],
			'tanggal' => $data['tanggal'],
			'biaya' => $data['biaya']
		];
		// var_dump($params);
		// die();
		$this->db->where('idmarketing', $data['gid1']);
		$this->db->update('marketing', $params);
	}


	public function hapus($id='')
	{
		$this->db->where('idmarketing', $id);
		$this->db->delete('marketing');
	}

	// //front-end
	// function get_agenda_home(){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC limit 3");
	// 	return $hsl;
	// }
	// function agenda(){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC");
	// 	return $hsl;
	// }
	// function agenda_perpage($offset,$limit){
	// 	$hsl=$this->db->query("SELECT tbl_agenda.*,DATE_FORMAT(agenda_tanggal,'%d/%m/%Y') AS tanggal FROM tbl_agenda ORDER BY agenda_id DESC limit $offset,$limit");
	// 	return $hsl;
	// }


} 