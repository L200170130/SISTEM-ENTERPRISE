<?php
class M_produksi extends CI_Model{

	function get_all_produksi(){
		$hsl=$this->db->query("SELECT * FROM produksi JOIN inventory ON produksi.idbarang = inventory.idbarang");
		return $hsl;
	}
		function get_all_barangproduksi(){
		$hsl1=$this->db->query("SELECT * FROM inventory");
		return $hsl1;
	}

	function simpan_produksi($tanggal,$totalproduksi,$biayaproduksi,$idbarang){
	 	/*$author=$this->session->userdata('nama');*/
	 	$hsl=$this->db->query("INSERT INTO produksi(idproduksi,idbarang,jumlahbarang,tanggalproduksi,biayaproduksi) VALUES (null,'$idbarang','$totalproduksi','$tanggal','$biayaproduksi')");
	 	return $hsl;
	}
 
	function simpan_akuntansi($tanggal,$biayaproduksi,$idbarang){
		$oke=$this->db->query("SELECT * FROM inventory where idbarang='$idbarang'");
		foreach ($oke->result_array() as $i) :
                       $namabarang=$i['namabarang'];
        endforeach;
	 	$hsl=$this->db->query("INSERT INTO accounting(idakuntan,jenisakuntansi,namaakuntansi,tanggal,Jumlah) VALUES (null,'Pengeluaran','Produksi $namabarang','$tanggal','$biayaproduksi')");
	 	return $hsl;
	}

	function simpan_stok($totalproduksi,$idbarang){
		$oke=$this->db->query("SELECT * FROM inventory where idbarang='$idbarang'");
		foreach ($oke->result_array() as $i) :
                       $stokbarang=$i['stokbarang'];
        endforeach;
        $jadi=$stokbarang+$totalproduksi;
	 	$hsl=$this->db->query("UPDATE inventory SET stokbarang='$jadi' where idbarang='$idbarang'");
	 	return $hsl;
	}

	function update_produksi($idproduksi,$tanggal,$totalproduksi,$biayaproduksi,$idbarang){
	 	$hsl=$this->db->query("UPDATE produksi SET idproduksi='$idproduksi',idbarang='$idbarang',jumlahbarang='$totalproduksi',tanggalproduksi='$tanggal',biayaproduksi='$biayaproduksi' where idproduksi='$idproduksi'");
	 	return $hsl;
	}

	function hapus_produksi($idproduksi){
	 	$hsl=$this->db->query("DELETE FROM produksi WHERE idproduksi='$idproduksi'");
	 	return $hsl;
	}

	// //Front-end
	// function get_pengumuman_home(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit 3");
	// 	return $hsl;
	// }

	// function pengumuman(){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC");
	// 	return $hsl;
	// }
	// function pengumuman_perpage($offset,$limit){
	// 	$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit $offset,$limit");
	// 	return $hsl;
	// }


} 